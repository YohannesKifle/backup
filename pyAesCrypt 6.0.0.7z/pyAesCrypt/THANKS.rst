Thanks
===============
* Thanks to `Ben Fisher`_ and `Dead4W`_ for providing patches to improve decryption speed.

* Thanks to `Thomas O'Neill`_ for suggesting and implementing the password option in the script.

* Thanks to `Harish Navnit`_ for pointing out an issue about input and output files.

* Thanks to `sander76`_ for finding an issue affecting output file removal.

* Thanks to `Dead4W`_ for improving CI.

* Thanks to `MySixSenses`_ for pointing out that there was no default buffer size.

.. _Ben Fisher: https://downpoured.github.io/

.. _Thomas O'Neill: https://github.com/toneill818

.. _Harish Navnit: https://github.com/harishnavnit

.. _sander76: https://github.com/sander76

.. _Dead4W: https://github.com/Dead4W

.. _MySixSenses: https://github.com/MySixSenses
